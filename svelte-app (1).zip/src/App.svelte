<script>
	import Person from "./Person.svelte";
	const people = [
		{id: 1, name: 'Maxim', age: 24, job: 'Frontend'},
		{id: 2, name: 'Helen', age: 17, job: 'Student'}
	]
	
	let name = 'Ingwar'
  let age = '20'
  let jobTitle = 'Backend'
	
	
</script>

<h1>Application</h1>


<style>

</style>

<Person name={people[0].name} age={people[0].age} job={people[0].job} />
<Person {...people[1]} />
<Person {name} {age} job={jobTitle}/>

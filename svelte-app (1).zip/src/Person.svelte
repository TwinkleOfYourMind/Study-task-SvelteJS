<script>
	export let name = 'Undefinded name'
  export let age = 'Undefinded age'
  export let job = 'Undefinded job'
</script>

<style>
  div {
    border:  1px solid black;
    padding: 1rem;
    margin-bottom: 1rem;
  }
</style>

<div>
  <p>Name: <b>{name}</b></p>
  <p>Job: <b>{job}</b></p>

  {#if age < 18}
  <p>Cant sell beer</p>
  {:else}
  <p>Do what you want</p>
  {/if}
</div>